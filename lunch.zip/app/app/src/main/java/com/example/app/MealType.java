package com.example.app;

public class MealType {

    private String mealType;

    public MealType(String mealType) {
        this.mealType = mealType;
    }

    public void setName(String mealType) {
        this.mealType = mealType;
    }

    public String getmealType() {
        return mealType;
    }
}
